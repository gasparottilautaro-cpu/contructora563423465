(() => {
  const plans = {
    '1': { title: 'Plan 1 · 80 cuotas', price: '80 cuotas de $800.000' },
    '2': { title: 'Plan 2 · 120 cuotas', price: '120 cuotas de $500.000' },
    '3': { title: 'Plan 3 · 280 cuotas', price: '280 cuotas de $300.000' }
  };
  const params = new URLSearchParams(window.location.search);
  const planSelect = document.querySelector('#final-plan');
  const planTitle = document.querySelector('#plan-title');
  const planPrice = document.querySelector('#plan-price');
  const form = document.querySelector('#registration-form');
  const steps = [...document.querySelectorAll('.form-step')];
  const progress = [...document.querySelectorAll('.form-progress span')];
  const prev = document.querySelector('#prev-step');
  const next = document.querySelector('#next-step');
  const error = document.querySelector('#form-error');
  const actions = document.querySelector('#form-actions');
  const success = document.querySelector('#form-success');
  let current = 0;

  function setPlan(value) {
    const plan = plans[value];
    if (!plan) {
      planTitle.textContent = 'Elegí tu plan';
      planPrice.textContent = 'Seleccioná una alternativa en la página principal';
      return;
    }
    planSelect.value = value;
    planTitle.textContent = plan.title;
    planPrice.textContent = plan.price;
  }
  setPlan(params.get('plan'));
  planSelect.addEventListener('change', () => setPlan(planSelect.value));

  // La fecha de nacimiento no puede ser futura; se exige mayoría de edad para esta solicitud de interés.
  const birthdate = document.querySelector('#birthdate');
  const today = new Date();
  const maxBirth = new Date(today.getFullYear() - 18, today.getMonth(), today.getDate());
  birthdate.max = `${maxBirth.getFullYear()}-${String(maxBirth.getMonth()+1).padStart(2,'0')}-${String(maxBirth.getDate()).padStart(2,'0')}`;

  function showStep(index) {
    current = index;
    steps.forEach((step, i) => { step.hidden = i !== current; });
    progress.forEach((bar, i) => bar.classList.toggle('active', i <= current));
    prev.disabled = current === 0;
    next.textContent = current === steps.length - 1 ? 'Finalizar demostración ✓' : 'Continuar →';
    error.classList.remove('show');
    document.querySelector('.form-card').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  function validateCurrent() {
    const fields = [...steps[current].querySelectorAll('input, select, textarea')];
    let valid = true;
    fields.forEach((field) => {
      field.setAttribute('aria-invalid', 'false');
      if (field.type === 'checkbox') {
        if (field.required && !field.checked) { valid = false; field.setAttribute('aria-invalid', 'true'); }
        return;
      }
      if (!field.checkValidity()) { valid = false; field.setAttribute('aria-invalid', 'true'); }
      if (field.id === 'birthdate' && field.value && field.value > birthdate.max) { valid = false; field.setAttribute('aria-invalid', 'true'); }
    });
    if (!valid) {
      error.textContent = 'Revisá los campos obligatorios y corregí los datos señalados antes de continuar.';
      error.classList.add('show');
      const firstInvalid = fields.find((field) => field.getAttribute('aria-invalid') === 'true');
      if (firstInvalid) firstInvalid.focus();
    }
    return valid;
  }

  next.addEventListener('click', () => {
    if (!validateCurrent()) return;
    if (current < steps.length - 1) {
      showStep(current + 1);
    } else {
      // Modo demostración: no se transmiten ni almacenan los valores del formulario.
      form.hidden = true;
      actions.hidden = true;
      document.querySelector('.form-progress').hidden = true;
      document.querySelector('.form-plan-summary').hidden = true;
      success.classList.add('show');
      success.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  });
  prev.addEventListener('click', () => { if (current > 0) showStep(current - 1); });
  form.addEventListener('input', (event) => event.target.setAttribute('aria-invalid', 'false'));
  form.addEventListener('change', (event) => event.target.setAttribute('aria-invalid', 'false'));
  document.querySelector('#year').textContent = new Date().getFullYear();
})();
