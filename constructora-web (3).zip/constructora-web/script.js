const menuToggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('.main-nav');

if (menuToggle && nav) {
  menuToggle.addEventListener('click', () => {
    const isOpen = nav.classList.toggle('open');
    menuToggle.setAttribute('aria-expanded', String(isOpen));
    menuToggle.setAttribute('aria-label', isOpen ? 'Cerrar menú' : 'Abrir menú');
  });

  nav.querySelectorAll('a').forEach((link) => {
    link.addEventListener('click', () => {
      nav.classList.remove('open');
      menuToggle.setAttribute('aria-expanded', 'false');
      menuToggle.setAttribute('aria-label', 'Abrir menú');
    });
  });
}

document.querySelectorAll('[data-plan]').forEach((link) => {
  link.addEventListener('click', () => {
    // Solo muestra el plan elegido en esta página; aún no se envía ninguna preinscripción.
    const note = document.querySelector('#selected-plan-note');
    if (note) note.textContent = `Plan de interés: ${link.dataset.plan}. Escribinos por WhatsApp para conocer las condiciones.`;
  });
});

document.querySelector('#year').textContent = new Date().getFullYear();

// Animaciones discretas al entrar cada sección en pantalla.
const revealTargets = document.querySelectorAll(
  '.hero-copy, .hero-visual, .intro .section-index, .intro-body, .feature, .plans-heading, .plan-card, .steps-section > .section-index, .steps-heading, .step, .gallery-intro, .gallery-card, .contact-section .section-index, .contact-content'
);

if ('IntersectionObserver' in window && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
  const revealObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -35px 0px' });

  revealTargets.forEach((element, index) => {
    element.classList.add('js-reveal');
    element.style.setProperty('--reveal-delay', `${(index % 3) * 90}ms`);
    revealObserver.observe(element);
  });
} else {
  revealTargets.forEach((element) => element.classList.add('is-visible'));
}
